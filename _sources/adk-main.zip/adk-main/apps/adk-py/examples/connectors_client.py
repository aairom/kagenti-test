# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import asyncio
import uuid

import a2a.client
import a2a.types
import httpx
from pydantic import HttpUrl

import kagenti_adk.a2a.extensions
from kagenti_adk.a2a.extensions import PlatformApiExtensionClient
from kagenti_adk.platform import use_platform_client
from kagenti_adk.platform.context import Context, ContextPermissions, Permissions


async def run(
    agent_id: str,
    connector_id: str,
    platform_base_url: str = "http://127.0.0.1:8333",
):
    platform_base_url = platform_base_url.rstrip("/")

    async with use_platform_client(
        base_url=platform_base_url,
    ):
        context = await Context.create(provider_id=agent_id)
        context_token = await context.generate_token(
            providers=[agent_id],
            grant_global_permissions=Permissions(connectors={"proxy"}),
            grant_context_permissions=ContextPermissions(context_data={"*"}),
        )

    async with httpx.AsyncClient(timeout=30) as httpx_client:
        card = await a2a.client.A2ACardResolver(
            httpx_client, base_url=platform_base_url + f"/api/v1/a2a/{agent_id}"
        ).get_agent_card()
        mcp_spec = kagenti_adk.a2a.extensions.MCPServiceExtensionSpec.from_agent_card(card)
        platform_spec = kagenti_adk.a2a.extensions.PlatformApiExtensionSpec.from_agent_card(card)

        if not mcp_spec:
            raise ValueError(f"Agent at {platform_base_url} does not support MCP service injection")
        if not platform_spec:
            raise ValueError(f"Agent at {platform_base_url} does not support platform service injection")

        mcp_extension_client = kagenti_adk.a2a.extensions.MCPServiceExtensionClient(mcp_spec)

        message = a2a.types.Message(
            message_id=str(uuid.uuid4()),
            role=a2a.types.Role.user,
            parts=[a2a.types.Part(root=a2a.types.TextPart(text="Howdy!"))],
            metadata=mcp_extension_client.fulfillment_metadata(
                mcp_fulfillments={
                    key: kagenti_adk.a2a.extensions.services.mcp.MCPFulfillment(
                        transport=kagenti_adk.a2a.extensions.services.mcp.StreamableHTTPTransport(
                            url="{platform_url}" + f"/api/v1/connectors/{connector_id}/mcp"
                        ),
                    )
                    for key in mcp_spec.params.mcp_demands
                }
            )
            | (
                PlatformApiExtensionClient(platform_spec).api_auth_metadata(
                    base_url=HttpUrl(platform_base_url),
                    auth_token=context_token.token,
                    expires_at=context_token.expires_at,
                )
                if platform_spec
                else {}
            ),
        )

        client = a2a.client.ClientFactory(a2a.client.ClientConfig(httpx_client=httpx_client, polling=True)).create(
            card=card
        )

        task = None
        async for event in client.send_message(message):
            if isinstance(event, a2a.types.Message):
                print(event)
                return
            task, _update = event

        print(task)


if __name__ == "__main__":
    asyncio.run(
        run(
            agent_id="fe80fbd3-79bf-7d10-52ce-fb80485f8215",
            connector_id="84c9d1a8-01b6-455d-8a2a-73386cfca8d8",
            platform_base_url="http://localhost:18333",
        )
    )
