# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Annotated

from a2a.types import Message
from pydantic import BaseModel

from kagenti_adk.a2a.extensions import (
    FormRender,
    FormServiceExtensionServer,
    FormServiceExtensionSpec,
    TextField,
)
from kagenti_adk.server import Server

server = Server()


class FormData(BaseModel):
    mood: str | None


@server.agent()
async def form_agent(
    _message: Message,
    form: Annotated[
        FormServiceExtensionServer,
        FormServiceExtensionSpec.demand(
            initial_form=FormRender(
                title="How are you?",
                fields=[TextField(id="mood", label="Mood", type="text", col_span=1)],
            )
        ),
    ],
):
    """Initial form agent"""
    initial_form = form.parse_initial_form(model=FormData)
    if initial_form is None:
        yield "No form data received."
    else:
        yield f"Your mood is {initial_form.mood}"


if __name__ == "__main__":
    server.run()
