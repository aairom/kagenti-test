/**
 * Copyright 2026 © IBM Corp.
 * SPDX-License-Identifier: Apache-2.0
 */

import type z from 'zod';

import type { agentDetailContributorSchema, agentDetailSchema, agentDetailToolSchema } from './schemas';

export enum InteractionMode {
  SingleTurn = 'single-turn',
  MultiTurn = 'multi-turn',
}

export type AgentDetailTool = z.infer<typeof agentDetailToolSchema>;

export type AgentDetailContributor = z.infer<typeof agentDetailContributorSchema>;

export type AgentDetail = z.infer<typeof agentDetailSchema>;
