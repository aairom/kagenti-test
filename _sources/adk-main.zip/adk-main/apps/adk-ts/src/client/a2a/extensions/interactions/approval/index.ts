/**
 * Copyright 2026 © IBM Corp.
 * SPDX-License-Identifier: Apache-2.0
 */

import z from 'zod';

import type { A2AUiExtension } from '../../../../core/extensions/types';
import { approvalRequestSchema, approvalResponseSchema } from './schemas';
import type { ApprovalRequest, ApprovalResponse } from './types';

export const APPROVAL_EXTENSION_URI = 'https://a2a-extensions.adk.kagenti.dev/interactions/approval/v1';

export const approvalExtension: A2AUiExtension<typeof APPROVAL_EXTENSION_URI, ApprovalRequest> = {
  getUri: () => APPROVAL_EXTENSION_URI,
  getMessageMetadataSchema: () => z.object({ [APPROVAL_EXTENSION_URI]: approvalRequestSchema }).partial(),
};

export const approvalResponseExtension: A2AUiExtension<typeof APPROVAL_EXTENSION_URI, ApprovalResponse> = {
  getUri: () => APPROVAL_EXTENSION_URI,
  getMessageMetadataSchema: () => z.object({ [APPROVAL_EXTENSION_URI]: approvalResponseSchema }).partial(),
};
