/**
 * Copyright 2026 © IBM Corp.
 * SPDX-License-Identifier: Apache-2.0
 */

export { default } from '@kagenti/adk-lint-config/eslint';
