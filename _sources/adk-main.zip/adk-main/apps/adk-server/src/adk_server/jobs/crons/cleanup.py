# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging

from kink import inject
from procrastinate import Blueprint, JobContext, builtin_tasks

from adk_server.jobs.queues import Queues
from adk_server.service_layer.services.a2a import A2AProxyService
from adk_server.service_layer.services.contexts import ContextService

blueprint = Blueprint()

logger = logging.getLogger(__name__)


@blueprint.periodic(cron="5 * * * *")  # pyrefly: ignore [bad-argument-type] -- bad typing in blueprint library
@blueprint.task(queueing_lock="cleanup_expired_context_resources", queue=str(Queues.CRON_CLEANUP))
@inject
async def cleanup_expired_context_resources(timestamp: int, context: ContextService) -> None:
    """Delete resources of contexts that haven't been used for several days."""
    deleted_stats = await context.expire_resources()
    logger.info(f"Deleted: {deleted_stats}")


@blueprint.periodic(cron="10 * * * *")  # pyrefly: ignore [bad-argument-type] -- bad typing in blueprint library
@blueprint.task(queueing_lock="cleanup_expired_a2a_requests", queue=str(Queues.CRON_CLEANUP))
@inject
async def cleanup_expired_a2a_tasks(timestamp: int, a2a_proxy: A2AProxyService) -> None:
    """Delete tracked request objects that haven't been used for several days."""
    deleted_stats = await a2a_proxy.expire_requests()
    logger.info(f"Deleted: {deleted_stats}")


@blueprint.periodic(cron="*/10 * * * *")  # pyrefly: ignore [bad-argument-type] -- bad typing in blueprint library
@blueprint.task(queueing_lock="remove_old_jobs", queue=str(Queues.CRON_CLEANUP), pass_context=True)
async def remove_old_jobs(context: JobContext, timestamp: int):
    return await builtin_tasks.remove_old_jobs(  # pyrefly: ignore [invalid-param-spec] -- bad typing in procrastinate library
        context,
        max_hours=1,
        remove_failed=True,
        remove_cancelled=True,
        remove_aborted=True,
    )
