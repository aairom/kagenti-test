# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
import re

import procrastinate
from procrastinate.app import WorkerOptions

from adk_server.configuration import Configuration
from adk_server.jobs.crons.cleanup import blueprint as cleanup_crons
from adk_server.jobs.crons.connector import blueprint as connector_crons
from adk_server.jobs.crons.model_provider import blueprint as model_provider_crons
from adk_server.jobs.crons.provider import blueprint as provider_crons
from adk_server.jobs.tasks.context import blueprint as context_tasks
from adk_server.jobs.tasks.file import blueprint as file_tasks

logger = logging.getLogger(__name__)

_app_created = False


def create_app(configuration: Configuration) -> procrastinate.App:
    global _app_created

    if _app_created:
        raise RuntimeError("App can be created only once (modifies global tasks in-place)")

    conn_string = str(configuration.persistence.db_url.get_secret_value())
    conn_string = re.sub(r"postgresql\+[a-zA-Z]+://", "postgresql://", conn_string)

    kwargs = {"options": f"-c search_path={configuration.persistence.procrastinate_schema}"}
    if configuration.persistence.db_use_ssl:
        kwargs["sslmode"] = "verify-full"
        if configuration.persistence.db_ssl_cert:
            kwargs["sslrootcert"] = str(configuration.persistence.db_ssl_cert)

    def exit_app_on_db_error(*_args, **_kwargs):
        import os
        import signal

        logger.critical("DB is not responding, forcing shutdown")

        os.kill(os.getpid(), signal.SIGTERM)

    app = procrastinate.App(
        connector=procrastinate.PsycopgConnector(
            conninfo=conn_string,
            reconnect_failed=exit_app_on_db_error,
            max_size=10,
            kwargs=kwargs,
        ),
        worker_defaults=WorkerOptions(install_signal_handlers=False),
    )
    app.add_tasks_from(blueprint=file_tasks, namespace="text_extraction")
    app.add_tasks_from(blueprint=context_tasks, namespace="context_tasks")
    app.add_tasks_from(blueprint=provider_crons, namespace="cron_provider")
    app.add_tasks_from(blueprint=model_provider_crons, namespace="cron_model_provider")
    app.add_tasks_from(blueprint=cleanup_crons, namespace="cron_cleanup")
    app.add_tasks_from(blueprint=connector_crons, namespace="cron_connector")
    _app_created = True
    return app
