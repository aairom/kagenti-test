# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0


from __future__ import annotations

import builtins
from collections.abc import AsyncIterator
from typing import Any, cast
from uuid import UUID

from kink import inject
from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    Row,
    String,
    Table,
    Text,
    UniqueConstraint,
    func,
    select,
)
from sqlalchemy import UUID as SQL_UUID
from sqlalchemy.ext.asyncio import AsyncConnection

from adk_server.domain.models.common import PaginatedResult
from adk_server.domain.models.file import (
    ExtractedFileInfo,
    ExtractionFormat,
    ExtractionStatus,
    File,
    FileType,
    TextExtraction,
)
from adk_server.domain.repositories.file import IFileRepository
from adk_server.exceptions import EntityNotFoundError
from adk_server.infrastructure.persistence.repositories.context import cursor_paginate
from adk_server.infrastructure.persistence.repositories.db_metadata import metadata
from adk_server.infrastructure.persistence.repositories.utils import sql_enum

files_table = Table(
    "files",
    metadata,
    Column("id", SQL_UUID, primary_key=True),
    Column("filename", String(256), nullable=False),
    Column("content_type", String(256), nullable=False),
    Column("file_size_bytes", Integer, nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("created_by", ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
    Column("file_type", sql_enum(FileType, name="file_type"), nullable=False),
    Column("parent_file_id", ForeignKey("files.id", ondelete="CASCADE"), nullable=True),
    Column("context_id", ForeignKey("contexts.id", ondelete="CASCADE"), nullable=True),
)

text_extractions_table = Table(
    "text_extractions",
    metadata,
    Column("id", SQL_UUID, primary_key=True),
    Column("file_id", ForeignKey("files.id", ondelete="CASCADE"), nullable=False, unique=True),
    Column("status", sql_enum(ExtractionStatus, name="extraction_status"), nullable=False),
    Column("job_id", String(255), nullable=True),
    Column("error_message", Text, nullable=True),
    Column("extraction_metadata", JSON, nullable=True),
    Column("started_at", DateTime(timezone=True), nullable=True),
    Column("finished_at", DateTime(timezone=True), nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False),
)

extraction_files_table = Table(
    "extraction_files",
    metadata,
    Column("extraction_id", ForeignKey("text_extractions.id", ondelete="CASCADE"), nullable=False),
    Column("file_id", ForeignKey("files.id", ondelete="CASCADE"), nullable=False),
    Column("format", String(50), nullable=True),
    # Ensure only one file per format per extraction
    UniqueConstraint("extraction_id", "format", name="uq_extraction_files_extraction_id_format"),
)


@inject
class SqlAlchemyFileRepository(IFileRepository):
    def __init__(self, connection: AsyncConnection):
        self.connection = connection

    async def create(self, *, file: File) -> None:
        query = files_table.insert().values(self._to_row(file))
        await self.connection.execute(query)

    async def update(self, *, file: File) -> None:
        query = files_table.update().where(files_table.c.id == file.id).values(self._to_row(file))
        await self.connection.execute(query)

    def _to_row(self, file: File) -> dict[str, Any]:
        return {
            "id": file.id,
            "filename": file.filename,
            "content_type": file.content_type,
            "created_at": file.created_at,
            "created_by": file.created_by,
            "file_size_bytes": file.file_size_bytes,
            "file_type": file.file_type,
            "parent_file_id": file.parent_file_id,
            "context_id": file.context_id,
        }

    def _to_file(self, row: Row):
        return File.model_validate(
            {
                "id": row.id,
                "filename": row.filename,
                "content_type": row.content_type,
                "created_at": row.created_at,
                "created_by": row.created_by,
                "file_size_bytes": row.file_size_bytes,
                "file_type": row.file_type,
                "parent_file_id": row.parent_file_id,
                "context_id": row.context_id,
            }
        )

    async def total_usage(self, *, user_id: UUID | None = None) -> int:
        query = select(func.coalesce(func.sum(files_table.c.file_size_bytes), 0))
        if user_id:
            query = query.where(files_table.c.created_by == user_id)
        return cast(int, await self.connection.scalar(query))

    async def get(
        self,
        *,
        file_id: UUID,
        user_id: UUID | None = None,
        context_id: UUID | None = None,
        file_type: FileType | None = None,
    ) -> File:
        query = files_table.select().where(files_table.c.id == file_id)
        if user_id:
            query = query.where(files_table.c.created_by == user_id)
        if context_id:
            query = query.where(files_table.c.context_id == context_id)
        if file_type:
            query = query.where(files_table.c.file_type == file_type)
        result = await self.connection.execute(query)
        if not (row := result.fetchone()):
            raise EntityNotFoundError(entity="file", id=file_id)
        return self._to_file(row)

    async def delete(
        self, *, file_id: UUID | None = None, user_id: UUID | None = None, context_id: UUID | None = None
    ) -> int:
        query = files_table.delete()

        conditions = []
        if file_id is not None:
            conditions.append(files_table.c.id == file_id)
        if context_id is not None:
            conditions.append(files_table.c.context_id == context_id)
        if user_id is not None:
            conditions.append(files_table.c.created_by == user_id)

        if not conditions:
            raise ValueError("At least one filter parameter must be provided")

        for condition in conditions:
            query = query.where(condition)
        result = await self.connection.execute(query)
        if not result.rowcount:
            raise EntityNotFoundError("file", file_id or "file to delete")
        return result.rowcount

    async def list(self, *, user_id: UUID | None = None, context_id: UUID | None = None) -> AsyncIterator[File]:
        query = files_table.select().where(files_table.c.file_type == FileType.USER_UPLOAD)
        if user_id:
            query = query.where(files_table.c.created_by == user_id)
        if context_id:
            query = query.where(files_table.c.context_id == context_id)
        async for row in await self.connection.stream(query):
            yield self._to_file(row)

    async def list_paginated(
        self,
        *,
        parent_id: UUID | None = None,
        context_id: UUID | None = None,
        content_type: str | None = None,
        filename_search: str | None = None,
        limit: int = 20,
        page_token: UUID | None = None,
        order: str = "desc",
        order_by: str = "created_at",
        user_id: UUID | None = None,
    ) -> PaginatedResult[File]:
        query = files_table.select()
        if user_id:
            query = query.where(files_table.c.created_by == user_id)

        if parent_id is not None:
            query = query.where(files_table.c.parent_file_id == parent_id)
        if context_id is not None:
            query = query.where(files_table.c.context_id == context_id)
        if content_type is not None:
            query = query.where(files_table.c.content_type == content_type)
        if filename_search is not None:
            query = query.where(files_table.c.filename.ilike(f"%{filename_search}%"))

        result = await cursor_paginate(
            connection=self.connection,
            query=query,
            id_column=files_table.c.id,
            limit=limit,
            after_cursor=page_token,
            order=order,
            order_column=getattr(files_table.c, order_by),
        )

        return PaginatedResult(
            items=[self._to_file(row) for row in result.items],
            total_count=result.total_count,
            has_more=result.has_more,
        )

    def _to_text_extraction(
        self, row: Row, extracted_files: builtins.list[ExtractedFileInfo] | None = None
    ) -> TextExtraction:
        return TextExtraction.model_validate(
            {
                "id": row.id,
                "file_id": row.file_id,
                "extracted_files": extracted_files or [],
                "status": row.status,
                "job_id": row.job_id,
                "error_message": row.error_message,
                "extraction_metadata": row.extraction_metadata,
                "started_at": row.started_at,
                "finished_at": row.finished_at,
                "created_at": row.created_at,
            }
        )

    async def create_extraction(self, *, extraction: TextExtraction) -> None:
        extraction_metadata = extraction.extraction_metadata
        query = text_extractions_table.insert().values(
            id=extraction.id,
            file_id=extraction.file_id,
            status=extraction.status,
            job_id=extraction.job_id,
            error_message=extraction.error_message,
            extraction_metadata=extraction_metadata and extraction_metadata.model_dump(mode="json"),
            started_at=extraction.started_at,
            finished_at=extraction.finished_at,
            created_at=extraction.created_at,
        )
        await self.connection.execute(query)

        # Insert extracted files with format into junction table
        if extraction.extracted_files:
            await self.connection.execute(
                extraction_files_table.insert(),
                [
                    {
                        "extraction_id": extraction.id,
                        "file_id": ef.file_id,
                        "format": ef.format.value if ef.format else None,
                    }
                    for ef in extraction.extracted_files
                ],
            )

    async def get_extraction_by_file_id(
        self, *, file_id: UUID, user_id: UUID | None = None, context_id: UUID | None = None
    ) -> TextExtraction:
        query = text_extractions_table.select().where(text_extractions_table.c.file_id == file_id)
        if context_id or user_id:
            query = query.join(files_table, text_extractions_table.c.file_id == files_table.c.id)
        if context_id:
            query = query.where(files_table.c.context_id == context_id)
        if user_id:
            query = query.where(files_table.c.created_by == user_id)

        result = await self.connection.execute(query)
        if not (row := result.fetchone()):
            raise EntityNotFoundError(entity="text_extraction", id=file_id, attribute="file_id")

        # Load extracted files with format from junction table
        extraction_files_query = extraction_files_table.select().where(extraction_files_table.c.extraction_id == row.id)
        extraction_files_result = await self.connection.execute(extraction_files_query)
        extracted_files = [
            ExtractedFileInfo(file_id=ef_row.file_id, format=ExtractionFormat(ef_row.format) if ef_row.format else None)
            for ef_row in extraction_files_result.fetchall()
        ]

        return self._to_text_extraction(row, extracted_files)

    async def update_extraction(self, *, extraction: TextExtraction) -> None:
        query = (
            text_extractions_table.update()
            .where(text_extractions_table.c.file_id == extraction.file_id)
            .values(
                status=extraction.status,
                job_id=extraction.job_id,
                error_message=extraction.error_message,
                extraction_metadata=extraction.extraction_metadata.model_dump(mode="json")
                if extraction.extraction_metadata
                else None,
                started_at=extraction.started_at,
                finished_at=extraction.finished_at,
            )
        )
        await self.connection.execute(query)

        # Get currently stored files
        current_files_query = extraction_files_table.select().where(
            extraction_files_table.c.extraction_id == extraction.id
        )
        current_files_result = await self.connection.execute(current_files_query)
        current_files = {(row.file_id, row.format) for row in current_files_result.fetchall()}

        # Only add new extracted files (never delete existing ones)
        if extraction.extracted_files:
            new_files = {(ef.file_id, ef.format.value if ef.format else None) for ef in extraction.extracted_files}

            # Check if any existing files are being removed
            if files_being_removed := current_files - new_files:
                raise ValueError(
                    f"Cannot remove extracted files. Attempting to remove {len(files_being_removed)} file(s). "
                    "Extracted files can only be added, not removed."
                )

            # Only insert files that don't already exist
            files_to_insert = [
                {
                    "extraction_id": extraction.id,
                    "file_id": ef.file_id,
                    "format": ef.format.value if ef.format else None,
                }
                for ef in extraction.extracted_files
                if (ef.file_id, ef.format.value if ef.format else None) not in current_files
            ]

            if files_to_insert:
                await self.connection.execute(
                    extraction_files_table.insert(),
                    files_to_insert,
                )
        elif current_files:
            # If there are current files but extraction.extracted_files is empty, that's an attempt to remove all files
            raise ValueError(
                f"Cannot remove extracted files. Attempting to remove all {len(current_files)} file(s). "
                "Extracted files can only be added, not removed."
            )

    async def delete_extraction(self, *, extraction_id: UUID) -> int:
        query = text_extractions_table.delete().where(text_extractions_table.c.id == extraction_id)
        result = await self.connection.execute(query)
        if not result.rowcount:
            raise EntityNotFoundError(entity="text_extraction", id=extraction_id)
        return result.rowcount
