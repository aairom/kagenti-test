# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import logging
from collections import deque
from collections.abc import AsyncGenerator, AsyncIterator, Callable, Iterable
from contextlib import asynccontextmanager
from datetime import datetime
from enum import StrEnum

import anyio
from anyio import WouldBlock
from pydantic import BaseModel, Field

from adk_server.utils.utils import utc_now

logger = logging.getLogger(__name__)


class ProcessLogType(StrEnum):
    STDOUT = "stdout"
    STDERR = "stderr"


class ProcessLogMessage(BaseModel, extra="allow"):
    stream: ProcessLogType = ProcessLogType.STDOUT
    message: str
    time: datetime = Field(default_factory=utc_now)
    error: bool | None = None
    finished: bool | None = None


class LogsContainer:
    def __init__(self, max_lines: int = 500):
        self._logs: deque[ProcessLogMessage] = deque(maxlen=max_lines)
        self._subscribers: set[Callable[[ProcessLogMessage], None]] = set()
        self._max_lines = max_lines

    def clear(self):
        self._logs.clear()

    def _notify_subscribers(self, log: ProcessLogMessage):
        for subscriber in self._subscribers:
            subscriber(log)

    def add(self, log: ProcessLogMessage):
        self._logs.append(log)
        self._notify_subscribers(log)

    def add_stdout(self, text: str):
        self.add(ProcessLogMessage(stream=ProcessLogType.STDOUT, message=text.rstrip("\n\r")))

    def add_stderr(self, text: str):
        self.add(ProcessLogMessage(stream=ProcessLogType.STDOUT, message=text.rstrip("\n\r")))

    def subscribe(self, handler: Callable[[ProcessLogMessage], None]):
        self._subscribers.add(handler)

    def unsubscribe(self, handler: Callable[[ProcessLogMessage], None]):
        self._subscribers.remove(handler)

    @property
    def logs(self) -> Iterable[ProcessLogMessage]:
        return self._logs

    @property
    def stdout(self) -> list[str]:
        return [log.message for log in self._logs if log.stream == ProcessLogType.STDOUT]

    @property
    def stderr(self) -> list[str]:
        return [log.message for log in self._logs if log.stream == ProcessLogType.STDERR]

    @asynccontextmanager
    async def stream(
        self, include_old: bool = True, max_buffer_size: int | None = None
    ) -> AsyncGenerator[AsyncIterator[ProcessLogMessage]]:
        max_buffer_size = max_buffer_size or self._max_lines * 2
        stream_send, stream_receive = anyio.create_memory_object_stream(max_buffer_size=max_buffer_size)

        def _handle_message(log: ProcessLogMessage):
            try:
                stream_send.send_nowait(log)
            except WouldBlock:
                logger.debug("Unable to stream logs to client due to a full buffer")

        if include_old:
            for message in self.logs:
                stream_send.send_nowait(message)

        try:
            self.subscribe(_handle_message)
            yield stream_receive
        finally:
            self.unsubscribe(_handle_message)
