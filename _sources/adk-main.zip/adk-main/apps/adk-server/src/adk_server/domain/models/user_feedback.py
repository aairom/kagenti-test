# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from uuid import UUID, uuid4

from pydantic import AwareDatetime, BaseModel, Field, field_validator

from adk_server.utils.utils import utc_now


class UserFeedback(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    provider_id: UUID
    task_id: UUID
    context_id: UUID
    rating: int = Field(..., description="Rating thats either 1 or -1")
    message: str
    comment_tags: list[str] | None = None
    comment: str | None = None
    created_at: AwareDatetime = Field(default_factory=utc_now)
    created_by: UUID
    trace_id: str | None
    agent_name: str | None = None

    @field_validator("rating")
    @classmethod
    def validate_rating(cls, v: int) -> int:
        if v not in [1, -1]:
            raise ValueError("Rating must be either 1 or -1")
        return v
