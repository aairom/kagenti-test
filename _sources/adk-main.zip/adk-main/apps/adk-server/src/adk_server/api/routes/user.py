# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
from typing import Annotated

from fastapi import APIRouter, Depends

from adk_server.api.dependencies import authorized_user
from adk_server.domain.models.permissions import AuthorizedUser
from adk_server.domain.models.user import User

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("")
async def get_user(user: Annotated[AuthorizedUser, Depends(authorized_user)]) -> User:
    return user.user
