# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import logging
from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, status

from adk_server.api.dependencies import (
    RequiresContextPermissions,
    VectorStoreServiceDependency,
)
from adk_server.api.schema.common import EntityModel
from adk_server.api.schema.vector_stores import (
    CreateVectorStoreRequest,
    SearchRequest,
)
from adk_server.domain.models.common import PaginatedResult
from adk_server.domain.models.permissions import AuthorizedUser
from adk_server.domain.models.vector_store import (
    VectorStore,
    VectorStoreDocument,
    VectorStoreItem,
    VectorStoreSearchResult,
)

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_vector_store(
    request: CreateVectorStoreRequest,
    vector_store_service: VectorStoreServiceDependency,
    user: Annotated[AuthorizedUser, Depends(RequiresContextPermissions(vector_stores={"write"}))],
) -> EntityModel[VectorStore]:
    """Create a new vector store."""
    return EntityModel(  # pyrefly: ignore [bad-return] -- TODO: fix the EntityModel hack so that both Pyrefly and FastAPI understand it
        await vector_store_service.create(
            name=request.name,
            dimension=request.dimension,
            user=user.user,
            model_id=request.model_id,
            context_id=user.context_id,
        )
    )


@router.get("/{vector_store_id}")
async def get_vector_store(
    vector_store_id: UUID,
    vector_store_service: VectorStoreServiceDependency,
    user: Annotated[AuthorizedUser, Depends(RequiresContextPermissions(vector_stores={"read"}))],
) -> EntityModel[VectorStore]:
    """Get a vector store by ID."""
    return EntityModel(  # pyrefly: ignore [bad-return] -- TODO: fix the EntityModel hack so that both Pyrefly and FastAPI understand it
        await vector_store_service.get(vector_store_id=vector_store_id, user=user.user, context_id=user.context_id)
    )


@router.delete("/{vector_store_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_vector_store(
    vector_store_id: UUID,
    vector_store_service: VectorStoreServiceDependency,
    user: Annotated[AuthorizedUser, Depends(RequiresContextPermissions(vector_stores={"write"}))],
) -> None:
    """Delete a vector store by ID."""
    await vector_store_service.delete(vector_store_id=vector_store_id, user=user.user, context_id=user.context_id)


@router.put("/{vector_store_id}")
async def add_items(
    vector_store_id: UUID,
    items: list[VectorStoreItem],
    vector_store_service: VectorStoreServiceDependency,
    user: Annotated[AuthorizedUser, Depends(RequiresContextPermissions(vector_stores={"write"}))],
) -> None:
    await vector_store_service.add_items(
        vector_store_id=vector_store_id, items=items, user=user.user, context_id=user.context_id
    )


@router.post("/{vector_store_id}/search")
async def search_with_vector(
    vector_store_id: UUID,
    request: SearchRequest,
    vector_store_service: VectorStoreServiceDependency,
    user: Annotated[AuthorizedUser, Depends(RequiresContextPermissions(vector_stores={"read"}))],
) -> PaginatedResult[VectorStoreSearchResult]:
    """Search a vector store using either text or a vector."""
    response = await vector_store_service.search(
        vector_store_id=vector_store_id,
        query_vector=request.query_vector,
        limit=request.limit,
        user=user.user,
        context_id=user.context_id,
    )
    return PaginatedResult(items=response, total_count=len(response))


@router.get("/{vector_store_id}/documents")
async def list_documents(
    vector_store_id: UUID,
    vector_store_service: VectorStoreServiceDependency,
    user: Annotated[AuthorizedUser, Depends(RequiresContextPermissions(vector_stores={"read"}))],
) -> PaginatedResult[VectorStoreDocument]:
    """List all documents in a vector store."""
    documents = await vector_store_service.list_documents(
        vector_store_id=vector_store_id, user=user.user, context_id=user.context_id
    )
    return PaginatedResult(items=documents, total_count=len(documents))


@router.delete("/{vector_store_id}/documents/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_document(
    vector_store_id: UUID,
    document_id: str,
    vector_store_service: VectorStoreServiceDependency,
    user: Annotated[AuthorizedUser, Depends(RequiresContextPermissions(vector_stores={"write"}))],
) -> None:
    """Delete a document by ID."""
    await vector_store_service.remove_documents(
        vector_store_id=vector_store_id, document_ids=[document_id], user=user.user, context_id=user.context_id
    )
