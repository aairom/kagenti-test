# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from typing import Annotated, Literal
from uuid import UUID

from pydantic import AnyUrl, AwareDatetime, BaseModel, Field

from adk_server.domain.models.common import Metadata
from adk_server.domain.models.connector import ConnectorState


class ConnectorCreateRequest(BaseModel):
    url: AnyUrl

    client_id: str | None = None
    client_secret: str | None = None

    metadata: Metadata | None = None

    match_preset: bool = True


class AuthorizationCodeRequest(BaseModel):
    type: Literal["code"] = "code"
    authorization_endpoint: AnyUrl


AuthorizationRequest = Annotated[AuthorizationCodeRequest, Field(discriminator="type")]


class ConnectorResponse(BaseModel):
    id: UUID
    url: AnyUrl
    state: ConnectorState
    auth_request: AuthorizationRequest | None
    disconnect_reason: str | None
    metadata: Metadata | None
    created_at: AwareDatetime
    updated_at: AwareDatetime
    created_by: UUID


class ConnectorConnectRequest(BaseModel):
    redirect_url: AnyUrl | None = None
    access_token: str | None = None


class ConnectorPresetResponse(BaseModel):
    url: AnyUrl
    metadata: Metadata | None
