# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0


from __future__ import annotations

import logging
from contextlib import AsyncExitStack
from uuid import UUID

import httpx
from authlib.oauth2 import OAuth2Error
from fastapi import Request, status
from fastapi.responses import StreamingResponse
from httpx import AsyncClient
from kink import inject
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client
from pydantic import AnyUrl

from adk_server.configuration import Configuration, ConnectorPreset
from adk_server.domain.models.common import Metadata
from adk_server.domain.models.connector import (
    Authorization,
    Connector,
    ConnectorState,
    Token,
)
from adk_server.domain.models.user import User
from adk_server.exceptions import PlatformError
from adk_server.service_layer.services.external_mcp_service import ExternalMcpService
from adk_server.service_layer.unit_of_work import IUnitOfWorkFactory

logger = logging.getLogger(__name__)


@inject
class ConnectorService:
    def __init__(
        self,
        uow: IUnitOfWorkFactory,
        configuration: Configuration,
        external_mcp: ExternalMcpService,
    ):
        self._uow = uow
        self._configuration = configuration
        self._proxy_client = httpx.AsyncClient(timeout=None)
        self._external_mcp = external_mcp

    async def create_connector(
        self,
        *,
        user: User,
        url: AnyUrl,
        client_id: str | None,
        client_secret: str | None,
        metadata: Metadata | None,
        match_preset: bool = True,
    ) -> Connector:
        if client_secret and not client_id:
            raise PlatformError(
                "client_id must be present when client_secret is specified", status_code=status.HTTP_400_BAD_REQUEST
            )

        preset = (
            next((p for p in self._configuration.connector.presets if str(p.url) == str(url)), None)
            if match_preset
            else None
        )
        if url.scheme not in ("http", "https"):
            raise PlatformError("Connector URL has an unsupported scheme", status_code=status.HTTP_400_BAD_REQUEST)

        if preset:
            if not client_id:
                client_id = preset.client_id
                client_secret = preset.client_secret
            metadata = metadata or preset.metadata

        connector = Connector(
            url=url,
            created_by=user.id,
            auth=Authorization(client_id=client_id, client_secret=client_secret) if client_id else None,
            metadata=metadata,
        )
        async with self._uow() as uow:
            await uow.connectors.create(connector=connector)
            await uow.commit()
        return connector

    async def read_connector(self, *, connector_id: UUID, user: User | None = None) -> Connector:
        async with self._uow() as uow:
            return await uow.connectors.get(connector_id=connector_id, user_id=user.id if user else None)

    async def delete_connector(self, *, connector_id: UUID, user: User | None = None) -> None:
        async with self._uow() as uow:
            connector = await uow.connectors.get(connector_id=connector_id, user_id=user.id if user else None)
            await self._external_mcp.revoke_token(connector=connector)
            await uow.connectors.delete(connector_id=connector_id, user_id=user.id if user else None)
            await uow.commit()

    async def list_connectors(self, *, user: User | None = None) -> list[Connector]:
        async with self._uow() as uow:
            return [c async for c in uow.connectors.list(user_id=user.id if user else None)]

    async def _handle_connection_error(
        self,
        err: Exception,
        connector: Connector,
        callback_uri: str,
        redirect_url: AnyUrl | None = None,
    ) -> None:
        """Handle various connection errors and update connector state accordingly."""
        if isinstance(err, OAuth2Error) or (
            isinstance(err, httpx.HTTPStatusError) and err.response.status_code == status.HTTP_401_UNAUTHORIZED
        ):
            await self._external_mcp.bootstrap_auth(
                connector=connector, callback_url=callback_uri, redirect_url=redirect_url
            )
            connector.transition(state=ConnectorState.auth_required)
        elif isinstance(err, httpx.HTTPStatusError):
            logger.error("Connector failed", exc_info=True)
            try:
                error = (await err.response.aread()).decode(err.response.encoding or "utf-8")
            except Exception:
                error = "Connector has returned an error"
            raise PlatformError(
                error,
                status_code=status.HTTP_502_BAD_GATEWAY,
            ) from err
        elif isinstance(err, httpx.RequestError):
            logger.error("Connector failed", exc_info=True)
            raise PlatformError(
                "Unable to establish connection with the connector",
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            ) from err
        else:
            logger.error("Connector failed", exc_info=True)
            raise PlatformError("Connection has failed") from err

    async def connect_connector(
        self,
        *,
        connector_id: UUID,
        callback_uri: str,
        redirect_url: AnyUrl | None = None,
        user: User | None = None,
        access_token: str | None = None,
    ) -> Connector:
        async with self._uow() as uow:
            connector = await uow.connectors.get(connector_id=connector_id, user_id=user.id if user else None)
        if access_token:
            if not connector.auth:
                connector.auth = Authorization()
            connector.auth.token = Token(access_token=access_token, token_type="bearer")

        try:
            await self.probe_connector(connector=connector)
            connector.transition(state=ConnectorState.connected)
        except Exception as err:
            await self._handle_connection_error(err, connector, callback_uri, redirect_url)

        async with self._uow() as uow:
            await uow.connectors.update(connector=connector)
            await uow.commit()
        return connector

    async def disconnect_connector(self, *, connector_id: UUID, user: User | None = None) -> Connector:
        async with self._uow() as uow:
            connector = await uow.connectors.get(connector_id=connector_id, user_id=user.id if user else None)

        if connector.state not in (ConnectorState.connected, ConnectorState.disconnected, ConnectorState.auth_required):
            raise PlatformError(
                "Connector must be in connected, disconnected or auth_required state",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        await self._external_mcp.revoke_token(connector=connector)

        if connector.auth:
            connector.auth.flow = None
        connector.transition(
            state=ConnectorState.disconnected, disconnect_reason="Client request", disconnect_permanent=True
        )

        async with self._uow() as uow:
            await uow.connectors.update(connector=connector)
            await uow.commit()
        return connector

    async def refresh_connector(self, *, connector_id: UUID, user: User | None = None) -> None:
        async with self._uow() as uow:
            connector = await uow.connectors.get(connector_id=connector_id, user_id=user.id if user else None)

        if not connector.refreshable:
            return

        try:
            await self.probe_connector(connector=connector)
            connector.transition(state=ConnectorState.connected)
        except Exception as err:
            if isinstance(err, httpx.HTTPStatusError):
                if err.response.status_code >= 400 and err.response.status_code < 500:
                    if err.response.status_code == status.HTTP_401_UNAUTHORIZED:
                        await self._external_mcp.revoke_token(connector=connector)
                        if connector.auth:
                            connector.auth.flow = None
                    connector.transition(
                        state=ConnectorState.disconnected, disconnect_reason=str(err), disconnect_permanent=True
                    )
                else:
                    connector.transition(
                        state=ConnectorState.disconnected, disconnect_reason=str(err), disconnect_permanent=False
                    )
            else:
                connector.transition(
                    state=ConnectorState.disconnected, disconnect_reason=str(err), disconnect_permanent=False
                )
        finally:
            async with self._uow() as uow:
                await uow.connectors.update(connector=connector)
                await uow.commit()

    async def list_presets(self) -> list[ConnectorPreset]:
        return self._configuration.connector.presets

    async def probe_connector(self, *, connector: Connector) -> None:
        def client_factory(headers=None, timeout=None, auth=None) -> AsyncClient:
            assert auth is None
            return self._external_mcp.create_http_client(connector=connector, headers=headers, timeout=timeout)

        try:
            async with (
                streamablehttp_client(
                    str(connector.url),
                    httpx_client_factory=client_factory,
                ) as (read, write, _),
                ClientSession(read, write) as session,
            ):
                await session.initialize()
        except ExceptionGroup as excgroup:
            logger.warning(f"Probe failed for MCP server {connector.url}: {excgroup}")
            if len(excgroup.exceptions) == 1:
                raise excgroup.exceptions[0] from excgroup
            raise excgroup from None

    async def mcp_proxy(self, *, connector_id: UUID, request: Request, user: User | None = None):
        connector = await self.read_connector(connector_id=connector_id, user=user)

        auth_headers = {}
        if (
            connector.auth
            and connector.state == ConnectorState.connected
            and connector.auth.token
            and connector.auth.token.token_type == "bearer"
        ):
            auth_headers["authorization"] = f"Bearer {connector.auth.token.access_token}"

        exit_stack = AsyncExitStack()
        try:
            response = await exit_stack.enter_async_context(
                self._proxy_client.stream(
                    request.method,
                    str(connector.url),
                    headers={
                        key: request.headers[key]
                        for key in ["accept", "content-type", "mcp-protocol-version", "mcp-session-id", "last-event-id"]
                        if key in request.headers
                    }
                    | auth_headers,
                    content=request.stream(),
                )
            )

            async def stream_fn():
                try:
                    async for chunk in response.aiter_bytes():
                        yield chunk
                finally:
                    await exit_stack.pop_all().aclose()

            return StreamingResponse(stream_fn(), status_code=response.status_code, headers=response.headers)
        except BaseException:
            await exit_stack.pop_all().aclose()
            raise
