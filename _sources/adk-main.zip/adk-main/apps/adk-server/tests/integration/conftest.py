# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import uuid
from collections.abc import Callable

import procrastinate
import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from kink import Container
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection

from adk_server.application import app
from adk_server.configuration import Configuration
from adk_server.jobs.procrastinate import create_app
from adk_server.utils.utils import utc_now


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def adk_server() -> Callable[[Container | None], TestClient]:
    client: TestClient | None = None

    # Hack: procrastinate app can be created only once, the action is destructive (modifies global task variables in-place)
    _procrastinate_app = create_app(Configuration())

    def server_factory(dependency_overrides: Container | None = None) -> TestClient:
        nonlocal client
        dependency_overrides = dependency_overrides or Container()
        dependency_overrides[procrastinate.App] = _procrastinate_app
        server_app = app(dependency_overrides=dependency_overrides, enable_workers=False)
        client = TestClient(server_app)
        return client

    yield server_factory


@pytest.fixture
async def normal_user(db_transaction: AsyncConnection) -> uuid.UUID:
    uid = uuid.uuid4()
    await db_transaction.execute(
        text("INSERT INTO users (id, email, created_at) VALUES (:id, :email, :created_at)"),
        [{"id": uid, "email": "dummy@beeai.dev", "created_at": utc_now()}],
    )
    return uid
