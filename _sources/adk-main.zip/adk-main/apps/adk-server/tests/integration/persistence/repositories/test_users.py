# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import uuid

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection

from adk_server.domain.models.user import User
from adk_server.exceptions import EntityNotFoundError
from adk_server.infrastructure.persistence.repositories.user import SqlAlchemyUserRepository

pytestmark = pytest.mark.integration


@pytest.fixture
async def test_user() -> User:
    return User(email=f"test-{uuid.uuid4()}@example.com")


async def test_create_user(db_transaction: AsyncConnection, test_user: User):
    # Create repository
    repository = SqlAlchemyUserRepository(connection=db_transaction)

    # Create user
    await repository.create(user=test_user)

    # Verify user was created
    result = await db_transaction.execute(text("SELECT * FROM users WHERE id = :id"), {"id": test_user.id})
    row = result.fetchone()
    assert row is not None
    assert str(row.id) == str(test_user.id)
    assert row.email == test_user.email
    assert row.created_at == test_user.created_at


async def test_get_user(db_transaction: AsyncConnection, test_user: User):
    # Create repository
    repository = SqlAlchemyUserRepository(connection=db_transaction)

    # Create user
    await repository.create(user=test_user)

    # Get user
    user = await repository.get(user_id=test_user.id)

    # Verify user
    assert user.id == test_user.id
    assert user.email == test_user.email
    assert user.role == test_user.role
    assert user.created_at == test_user.created_at


async def test_get_user_not_found(db_transaction: AsyncConnection):
    # Create repository
    repository = SqlAlchemyUserRepository(connection=db_transaction)

    # Try to get non-existent user
    with pytest.raises(EntityNotFoundError):
        await repository.get(user_id=uuid.uuid4())

    # Try to get non-existent user by email
    with pytest.raises(EntityNotFoundError):
        await repository.get_by_email(email="nonexistent@example.com")


async def test_get_user_by_email(db_transaction: AsyncConnection, test_user: User):
    # Create repository
    repository = SqlAlchemyUserRepository(connection=db_transaction)

    # Create user
    await repository.create(user=test_user)

    # Get user by email
    user = await repository.get_by_email(email=test_user.email)

    # Verify user
    assert user.id == test_user.id
    assert user.email == test_user.email
    assert user.role == test_user.role
    assert user.created_at == test_user.created_at


async def test_delete_user(db_transaction: AsyncConnection, test_user: User):
    # Create repository
    repository = SqlAlchemyUserRepository(connection=db_transaction)

    # Create user
    await repository.create(user=test_user)

    # Verify user was created
    result = await db_transaction.execute(text("SELECT * FROM users WHERE id = :id"), {"id": test_user.id})
    assert result.fetchone() is not None

    # Delete user
    await repository.delete(user_id=test_user.id)

    # Verify user was deleted
    result = await db_transaction.execute(text("SELECT * FROM users WHERE id = :id"), {"id": test_user.id})
    assert result.fetchone() is None
