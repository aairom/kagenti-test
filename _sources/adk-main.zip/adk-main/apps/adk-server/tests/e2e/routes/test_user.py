# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import pytest
from kagenti_adk.platform import User

pytestmark = pytest.mark.e2e


@pytest.mark.usefixtures("setup_platform_client", "test_admin")
async def test_get_user(test_admin):
    user = await User.get()
    assert user.email == f"{test_admin[0]}@beeai.dev"
    assert user.role == "admin"
