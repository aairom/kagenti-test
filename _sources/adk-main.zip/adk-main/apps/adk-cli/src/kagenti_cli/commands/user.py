# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import typing
from datetime import datetime

import typer
from kagenti_adk.platform import User
from kagenti_adk.platform.user import UserRole
from rich.table import Column

from kagenti_cli.async_typer import AsyncTyper, console, create_table
from kagenti_cli.configuration import Configuration
from kagenti_cli.server_utils import announce_server_action, confirm_server_action

app = AsyncTyper()
configuration = Configuration()

ROLE_DISPLAY = {
    "admin": "[red]admin[/red]",
    "developer": "[cyan]developer[/cyan]",
    "user": "user",
}


@app.command("list", help="List platform users [Admin only]")
async def list_users(
    email: typing.Annotated[str | None, typer.Option(help="Filter by email (case-insensitive partial match)")] = None,
    limit: typing.Annotated[int, typer.Option(help="Results per page (1-100)")] = 40,
    after: typing.Annotated[str | None, typer.Option(help="Pagination cursor (page_token)")] = None,
):
    announce_server_action("Listing users on")

    async with configuration.use_platform_client():
        result = await User.list(email=email, limit=limit, page_token=after)

        items = result.items
        has_more = result.has_more
        next_page_token = result.next_page_token

    with create_table(
        Column("ID", style="yellow"),
        Column("Email"),
        Column("Role"),
        Column("Created"),
        no_wrap=True,
    ) as table:
        for user in items:
            role_display = ROLE_DISPLAY.get(user.role, user.role)

            created_at = _format_date(user.created_at)

            table.add_row(
                user.id,
                user.email,
                role_display,
                created_at,
            )

    console.print()
    console.print(table)

    if has_more and next_page_token:
        console.print(f"\n[dim]Use --after {next_page_token} to see more[/dim]")


@app.command("set-role", help="Change user role [Admin only]")
async def set_role(
    user_id: typing.Annotated[str, typer.Argument(help="User UUID")],
    role: typing.Annotated[UserRole, typer.Argument(help="Target role (admin, developer, user)")],
    yes: typing.Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation prompts.")] = False,
):
    url = announce_server_action(f"Changing user {user_id} to role '{role}' on")
    await confirm_server_action("Proceed with role change on", url=url, yes=yes)

    async with configuration.use_platform_client():
        result = await User.set_role(user_id, UserRole(role))

        role_display = ROLE_DISPLAY.get(result.new_role, result.new_role)

        console.success(f"User role updated to [cyan]{role_display}[/cyan]")


def _format_date(dt: datetime | None) -> str:
    if not dt:
        return "-"
    return dt.strftime("%Y-%m-%d %H:%M")
