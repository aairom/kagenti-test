# Copyright 2026 © IBM Corp.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import asyncio
import logging
import re
import typing
from copy import deepcopy

import kagenti_adk  # noqa: F401 -- imported early due to Pydantic patches
import typer

import kagenti_cli.commands.agent
import kagenti_cli.commands.build
import kagenti_cli.commands.connector
import kagenti_cli.commands.model
import kagenti_cli.commands.platform
import kagenti_cli.commands.self
import kagenti_cli.commands.server

# import kagenti_cli.commands.user
from kagenti_cli.async_typer import AsyncTyper
from kagenti_cli.configuration import Configuration

logging.basicConfig(level=logging.INFO if Configuration().debug else logging.FATAL)
logging.getLogger("httpx").setLevel(logging.WARNING)  # not sure why this is necessary


HELP_TEXT = """\
Usage: kagenti-adk [OPTIONS] COMMAND [ARGS]...

╭─ Getting Started ──────────────────────────────────────────────────────────╮
│ ui       Launch the web interface                                          │
│ admin    Launch the admin console                                          │
│ list     View all available agents                                         │
│ info     Show agent details                                                │
│ run      Run an agent interactively                                        │
╰────────────────────────────────────────────────────────────────────────────╯

╭─ Agent Management [Admin only] ────────────────────────────────────────────╮
│ add                               Install an agent                         │
│ remove                            Uninstall an agent                       │
│ update                            Update an agent                          │
│ build                             Build an agent image locally              │
╰────────────────────────────────────────────────────────────────────────────╯

╭─ Platform & Configuration ─────────────────────────────────────────────────╮
| connector       Manage connectors to external services                     │
│ model           Configure 15+ LLM providers [Admin only]                   │
│ platform        Start, stop, or delete local platform [Local only]         │
│ server          Connect to remote Kagenti ADK servers                      │
│ self version    Show Kagenti ADK CLI and Platform version                  │
│ self upgrade    Upgrade Kagenti ADK CLI and Platform [Local only]          │
│ self uninstall  Uninstall Kagenti ADK CLI and Platform [Local only]        │
╰────────────────────────────────────────────────────────────────────────────╯

╭─ Options ──────────────────────────────────────────────────────────────────╮
│ --version             Show CLI version and exit                            │
│ --help                Show this help message                               │
│ --show-completion     Show tab completion script                           │
│ --install-completion  Enable tab completion for commands                   │
╰────────────────────────────────────────────────────────────────────────────╯
"""


app = AsyncTyper()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    help: bool = typer.Option(False, "--help", help="Show this message and exit."),
    version: bool = typer.Option(False, "--version", help="Show CLI version and exit."),
):
    if version:
        asyncio.run(kagenti_cli.commands.self.version())
        raise typer.Exit()
    if help or ctx.invoked_subcommand is None:
        typer.echo(HELP_TEXT)
        raise typer.Exit()


app.add_typer(
    kagenti_cli.commands.model.app, name="model", no_args_is_help=True, help="Manage model providers. [Admin only]"
)
app.add_typer(
    kagenti_cli.commands.agent.app,
    name="agent",
    no_args_is_help=True,
    help="Manage agents. Some commands are [Admin only].",
)
app.add_typer(
    kagenti_cli.commands.connector.app,
    name="connector",
    no_args_is_help=True,
    help="Manage connectors to external services.",
)
app.add_typer(
    kagenti_cli.commands.platform.app,
    name="platform",
    no_args_is_help=True,
    help="Manage Kagenti ADK platform. [Local only]",
)
app.add_typer(
    kagenti_cli.commands.server.app,
    name="server",
    no_args_is_help=True,
    help="Manage Kagenti ADK servers and authentication.",
)
app.add_typer(
    kagenti_cli.commands.self.app,
    name="self",
    no_args_is_help=True,
    help="Manage Kagenti ADK installation.",
    hidden=True,
)
# TODO: Implement keycloak integration
# app.add_typer(
#     kagenti_cli.commands.user.app,
#     name="user",
#     no_args_is_help=True,
#     help="Manage users. [Admin only]",
# )


app.add_typer(kagenti_cli.commands.build.app, name="", no_args_is_help=True, help="Build agent images.")

agent_alias = deepcopy(kagenti_cli.commands.agent.app)
for cmd in agent_alias.registered_commands:
    cmd.rich_help_panel = "Agent commands"

app.add_typer(agent_alias, name="", no_args_is_help=True)


@app.command("version")
async def version(
    verbose: typing.Annotated[bool, typer.Option("-v", "--verbose", help="Show verbose output")] = False,
):
    """Print version of the Kagenti ADK CLI."""
    import kagenti_cli.commands.self

    await kagenti_cli.commands.self.version(verbose=verbose)


@app.command("ui")
async def ui():
    """Launch the graphical interface."""
    import webbrowser

    import kagenti_cli.commands.model

    await kagenti_cli.commands.model.ensure_llm_provider()

    config = Configuration()
    active_server = config.auth_manager.active_server

    if active_server:
        if "adk-api.localtest.me" in active_server:
            ui_url = active_server.replace("adk-api.localtest.me", "adk.localtest.me")
        elif re.search(r"(localhost|127\.0\.0\.1):8333", active_server):
            ui_url = re.sub(r":8333", ":8334", active_server)
        else:
            ui_url = active_server
    else:
        ui_url = "http://adk.localtest.me:8080"

    webbrowser.open(ui_url)


@app.command("admin")
async def admin():
    """Launch the admin console."""
    import webbrowser

    config = Configuration()
    active_server = config.auth_manager.active_server

    if active_server:
        if "localtest.me" in active_server:
            admin_url = re.sub(r"://[^:/]+\.localtest\.me", "://kagenti-ui.localtest.me", active_server)
        elif re.search(r"(localhost|127\.0\.0\.1):8333", active_server):
            admin_url = re.sub(r"(localhost|127\.0\.0\.1):8333", "kagenti-ui.localtest.me:8080", active_server)
        else:
            admin_url = active_server
    else:
        admin_url = "http://kagenti-ui.localtest.me:8080"

    webbrowser.open(admin_url)


if __name__ == "__main__":
    app()
